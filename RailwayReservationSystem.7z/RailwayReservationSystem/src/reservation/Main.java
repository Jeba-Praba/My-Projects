package reservation;

import java.util.Scanner;

public class Main {
	static Passenger p;
	static TicketBooker booker;
	
	static void bookTicket(Passenger p)
	{
		booker=new TicketBooker();
		if(TicketBooker.availableWaitingList==0)
		{
			System.out.println("No Tickets Available");
			return;
		}
		//CASE 1:PREFERRED BERTH AVAILABLE
		if(p.berthPreference.equals("L")&&TicketBooker.availableLowerBerths>0||
				p.berthPreference.equals("M")&&TicketBooker.availableMiddleBerths>0||
				p.berthPreference.equals("U")&&TicketBooker.availableUpperBerths>0)

		{
			System.out.println("Preffered Berth Available");
			if(p.berthPreference.equals("L"))
			{
				System.out.println("Lower Berth Given");
				booker.bookTicket(p,(TicketBooker.lowerBerthPositions.get(0)),"L");
				TicketBooker.lowerBerthPositions.remove(0);
				TicketBooker.availableLowerBerths--;
				
			}
			if(p.berthPreference.equals("M"))
			{
				System.out.println("Middle Berth Given");
				booker.bookTicket(p,(TicketBooker.middleBerthPositions.get(0)),"M");
				TicketBooker.middleBerthPositions.remove(0);
				TicketBooker.availableMiddleBerths--;
				
			}
			if(p.berthPreference.equals("U"))
			{
				System.out.println("Upper Berth Given");
				booker.bookTicket(p,(TicketBooker.upperBerthPositions.get(0)),"U");
				TicketBooker.upperBerthPositions.remove(0);
				TicketBooker.availableUpperBerths--;
				
			}
		}
		//CASE 1:PREFERRED BERTH NOT AVAILABLE CHECK Other Availability

		else if(TicketBooker.availableLowerBerths>0)
		{
			System.out.println("Lower Berth Given");
			booker.bookTicket(p,(TicketBooker.lowerBerthPositions.get(0)),"L");
			TicketBooker.lowerBerthPositions.remove(0);
			TicketBooker.availableLowerBerths--;
		}
		
		
		else if(TicketBooker.availableMiddleBerths>0)
		{
			System.out.println("Middle Berth Given");
			booker.bookTicket(p,(TicketBooker.middleBerthPositions.get(0)),"M");
			TicketBooker.middleBerthPositions.remove(0);
			TicketBooker.availableMiddleBerths--;
		}
		else if(TicketBooker.availableUpperBerths>0)
		{
			System.out.println("Upper Berth Given");
			booker.bookTicket(p,(TicketBooker.upperBerthPositions.get(0)),"U");
			TicketBooker.upperBerthPositions.remove(0);
			TicketBooker.availableUpperBerths--;
		}
		
		else if(TicketBooker.availableRACTickets>0)
		{
			System.out.println("RAC Available");
			booker.addToRAC(p,(TicketBooker.racPositions.get(0)),"RAC");
		
		}
		
		else if(TicketBooker.availableWaitingList>0)
		{
			System.out.println("Added to Waiting List");
			booker.addToWaitingList(p,(TicketBooker.waitingListPositions.get(0)),"WL");
		
		}
			
	}
	
	//Cancel Ticket
	
	public static void cancelTicket(int passengerId)
	{
		booker=new TicketBooker();
		if(!TicketBooker.passengers.containsKey(passengerId))
		{
			System.out.println("Passenger Details Unknown");

		}
		else
			booker.cancelTicket(passengerId);
	}
	
	public static void main(String[] args) {
		try
		{
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		boolean loop=true;
		while(loop)
		{
			System.out.println("\n 1.Book Ticket \n 2.Cancel Ticket \n 3.Available Tickets \n 4.Booked "
					+ "Tickets \n 5.Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			
			switch (choice) {
			case 1:
				System.out.println("Enter Passenger Name,Age and Berth Preference(L,M,U)");
				String name=sc.next();
				int age=sc.nextInt();
				String berthPreference=sc.next();
				p=new Passenger(age, name, berthPreference);
				bookTicket(p);
				break;
				
			case 2:
				System.out.println("Enter Passenger Id To Cancel");
				int id=sc.nextInt();
				cancelTicket(id);
				break;
			
			case 3:
				booker=new TicketBooker();
				booker.printAvailableTickets();
				break;
			case 4:
				booker=new TicketBooker();
				booker.printPassengers();
				break;
			case 5:
				loop=false;
				

			default:
				break;
			}
		}
		}
		catch (Exception e) {
			System.out.println(e);
		}

	}

}
