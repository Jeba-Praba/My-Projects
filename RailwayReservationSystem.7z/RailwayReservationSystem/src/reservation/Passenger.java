package reservation;

public class Passenger {
	
	public static int id=1;
	public int passengerId;
	public int age;
	public String name;
	public String berthPreference;
	public String allotted="";
	public int seatNo;
	
	
	public Passenger(int age,String name,String berthPreferance) {
		this.age=age;
		this.name=name;
		this.berthPreference=berthPreferance;
		this.passengerId=id++;
		this.allotted="";
		this.seatNo=-1;
	}
	

}
