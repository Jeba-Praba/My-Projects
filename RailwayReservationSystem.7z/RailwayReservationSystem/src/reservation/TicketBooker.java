package reservation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class TicketBooker {
			
	static int availableLowerBerths=1;
	static int availableMiddleBerths=1;
	static int availableUpperBerths=1;
	static int availableRACTickets=1;
	static int availableWaitingList=1;
	
	static Queue<Integer> waitingList=new LinkedList<>();
	static Queue<Integer> racList=new LinkedList<>();
	static List<Integer> bookedLists=new ArrayList<Integer>();


	static List<Integer> lowerBerthPositions=new ArrayList<Integer>(Arrays.asList(1));
	static List<Integer> middleBerthPositions=new ArrayList<Integer>(Arrays.asList(1));
	static List<Integer> upperBerthPositions=new ArrayList<Integer>(Arrays.asList(1));
	static List<Integer> racPositions=new ArrayList<Integer>(Arrays.asList(1));
	static List<Integer> waitingListPositions=new ArrayList<Integer>(Arrays.asList(1));
	
	static Map<Integer, Passenger> passengers=new HashMap<>();


	public void bookTicket(Passenger p,int berthInfo,String allotedBerth)
	{
		p.seatNo=berthInfo;
		p.allotted=allotedBerth;
		passengers.put(p.passengerId, p);
		bookedLists.add(p.passengerId);
		System.out.println("....................................Booked Successfully");
		
	}
	
	public void addToRAC(Passenger p,int berthInfo,String allotedBerth)
	{
		p.seatNo=berthInfo;
		p.allotted=allotedBerth;
		passengers.put(p.passengerId, p);
		racList.add(p.passengerId);
		availableRACTickets--;
		racPositions.remove(0);
		System.out.println("....................................Added to RAC Successfully");
		
	}
	
	public void addToWaitingList(Passenger p,int berthInfo,String allotedBerth)
	{
		p.seatNo=berthInfo;
		p.allotted=allotedBerth;
		passengers.put(p.passengerId, p);
		waitingList.add(p.passengerId);
		availableWaitingList--;
		waitingListPositions.remove(0);
		System.out.println("....................................Added to Waiting List Successfully");
		
	}

	public void cancelTicket(int passengerId)
	{
		
		Passenger p=passengers.get(passengerId);
		passengers.remove(Integer.valueOf(passengerId)); //remove from HashMap
	
		
		if(bookedLists.contains(passengerId))
		{
			bookedLists.remove(Integer.valueOf(passengerId));
			int bookedSeatNo=p.seatNo;
			System.out.println("..................Cancelled Successfully");
			
			if(p.allotted.equals("L"))
			{
				availableLowerBerths++;
				lowerBerthPositions.add(bookedSeatNo);
			}
			else if(p.allotted.equals("M"))
			{
				availableMiddleBerths++;
				middleBerthPositions.add(bookedSeatNo);
			}
			else if(p.allotted.equals("U"))
			{
				availableUpperBerths++;
				upperBerthPositions.add(bookedSeatNo);
			}
			
			if(racList.size()>0)
			{
				Passenger passengerFromRAC=passengers.get(racList.poll());
				int positionRAC=passengerFromRAC.seatNo;
				racPositions.add(positionRAC);
				racList.remove(Integer.valueOf(passengerFromRAC.passengerId));
				availableRACTickets++;
				waitingListToRAC(passengerId);	
				
				Main.bookTicket(passengerFromRAC); //book for RAC To Confirm
			}
		
		}
		else if(waitingList.contains(passengerId))
		{
			waitingList.remove(Integer.valueOf(passengerId)); 
			int bookedSeatNo=p.seatNo;
			System.out.println("..................Cancelled Successfully");

			availableWaitingList++;
			waitingListPositions.add(bookedSeatNo);
			
		}
		else if(racList.contains(passengerId))
		{
			racList.remove(Integer.valueOf(passengerId)); 
			int bookedSeatNo=p.seatNo;
			System.out.println("..................Cancelled Successfully");
			
			availableRACTickets++;
			racPositions.add(bookedSeatNo);
			waitingListToRAC(passengerId);
		}
		
	
	}
	
	public void waitingListToRAC(int passengerId)
	{
		if(waitingList.size()>0)
		{
			Passenger passengerFromWL=passengers.get(waitingList.poll());
			int positionWL=passengerFromWL.seatNo;
			waitingListPositions.add(positionWL);
			waitingList.remove(Integer.valueOf(passengerFromWL.passengerId));
	
			
			passengerFromWL.seatNo=racPositions.get(0);
			passengerFromWL.allotted="RAC";
			racPositions.remove(0);
			racList.add(passengerFromWL.passengerId);			
			availableWaitingList++;			
			availableRACTickets--;
			
		}
	}
	public void printAvailableTickets()
	{
		System.out.println("Available Lower Berth.."+availableLowerBerths);
		System.out.println("Available Middle Berth.."+availableMiddleBerths);
		System.out.println("Available Upper Berth.."+availableUpperBerths);
		System.out.println("Available RAC Tickets.."+availableRACTickets);
		System.out.println("Available Waiting List .."+availableWaitingList);
		System.out.println("................................................");

	}
	
	public void printPassengers()
	{
		if(passengers.size()==0)
		{
			System.out.println("No Passengers Available");
			return;
		}
		for(Passenger p:passengers.values())
		{
			System.out.println("PASSENGER ID  :  "+p.passengerId);
			System.out.println("Name          :  "+p.name);
			System.out.println("Age           :  "+p.age);
			System.out.println("Status        :  "+p.seatNo+"__"+p.allotted);
			System.out.println("..............................");
		}
	}
	
	
}
